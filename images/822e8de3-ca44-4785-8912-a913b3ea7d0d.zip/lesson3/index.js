// extra tasks




// let random_number = parseInt(Math.random()*10)
// if (random_number % 2 ===0) {
// console.log("son juft");
// }
//  else{
//     console.log("son toq");
// }


// 2.masal


// let number = +prompt ("son kirit malol kelmasa")
// console.log(number);
// console.log(isNaN(number));

// if (isNaN(number)) {
//     console.log("son kirit baraka topgurrr , inson!");
// }
// else {
//     if (number % 2 === 0) {
//        console.log("son juft");
//     }

//     else{
//         console.log("son toq");
//     }
// }


// 3.masala

// let random_number = parseInt(Math.random()*10)
// console.log(random_number);

// let number = prompt("ixtiyoriy son kiriting")
// console.log(number);

// let difference = Math.abs(random_number - number)
// if (random_number === number) {
//     console.log("sonlar teng");
// }
// else{
//     console.log(`sonlar orasidagi farq ${difference}`);
// }

// 4.masala

// let number = +prompt("ixtiyoriy son kiriting")
// console.log(number);

// if (number % 7 == 0) {
//     console.log("Sunday");
// }
// else {
//     if (number % 7 == 1)  {
//        console.log("Monday");
//     }else{
//   if (number % 7 == 2) {
//     console.log("Tuesday");
//    } else{
//     if (number % 7 == 3) {
//          console.log("wenesday");
//     }else{
//     if (number % 7 == 4) {
//          console.log("Thursday");
//     }else{
//     if (number % 7 == 5) {
//          console.log("friday");
//     }else{
//     if (number % 7 == 6) {
//          console.log("Saturday");
//     }
//    }
//    }
//    }
//    }
//     }

// }


// 5.masala

// let number = +prompt("ixtiyoriy son kiriting")
// console.log(number);

// let number2 = +prompt("ixtiyoriy son kiriting")
// console.log(number2);
// if (number&&number2 > 0) {
//     console.log("ikkalsi ham musbat");
// } else { if (number > 0) {
//     console.log("faqat number1 musbat");
// } else { if (number2 > 0) {
//     console.log("faqat number2 musbat");
// }

// }

// }



// 6.masala

// let number = +prompt("ixtiyoriy son kiriting")
// console.log(number);

// let number2 = +prompt("ixtiyoriy son kiriting")
// console.log(number2);

// let number3 = +prompt("ixtiyoriy son kiriting")
// console.log(number3);

// if (number > number2 ) {
//      if (number2 > number3) {
//          console.log("number1 hammasidan katta");
//     }
// }else{
//     if (number > number3 ) {
//      if (number3 > number2) {
//          console.log("number1 hammasidan katta");
//     }
// }if (number2 > number ) {
//      if (number > number3) {
//          console.log("number2 hammasidan katta");
//     }

// }
//  else{
//     if (number2 > number3 ) {
//      if (number3 > number) {
//          console.log("number2 hammasidan katta");
//     }else{
//  if (number2 > number ) {
//      if (number > number3) {
//          console.log("number2 hammasidan katta");
//     }
//     }else{
//          if (number3 > number2 ) {
//      if (number2 > number) {
//          console.log("number3 hammasidan katta");
//     }else{
//  if (number3 > number ) {
//      if (number > number2) {
//          console.log("number3 hammasidan katta");
//     }
//     }

// }
//  }}
//     }}}}




// let number = +prompt("yoshiz kiriting")
// console.log(number);

// if (number <= 18) {
//     alert("siz balogatga yetmagansiz")
// } else{
//     if (number >=40 ) {
//     alert("siz qarib qoilibsiz")
// }else{
//      if (number<40 &&number>18 ) {
//     alert("sizga ruhsat bor")
// }
// }}






// .masala

// let number = +prompt("ixtiyoriy son kiriting")
// console.log(number);

// let number2 = +prompt("ixtiyoriy son kiriting")
// console.log(number2);

// let number3 = +prompt("ixtiyoriy son kiriting")
// console.log(number3);

// if (number > number2 && number2 > number3) {
//     alert("number1 hammasidan katta")
// }else{
//     if (number > number3 && number3 > number2) {
//         alert("number1 hammasidan katta")
//     }
// }
// if (number2 > number && number > number3) {
//     alert("number2 hammasidan katta")
// }else{
//     if (number2 > number3 && number3 > number) {
//         alert("number2 hammasidan katta")
//     }
// }

// if (number3 > number && number > number2) {
//     alert("number3 hammasidan katta")
// }else{
//     if (number3 > number2 && number2 > number) {
//         alert("number3 hammasidan katta")
//     }
// }

// 2.masala

// let number = +prompt("ixtiyoriy son kiriting")
// console.log(number);

// if (number >= 1000) {
//     alert("lux xona")
// }else{
//     if (number >= 500) {
//         alert("yarim lux xona")
//     }
//     else{
//         if (number >= 200) {
//             alert("oddiy xona")
//         }else{
//             alert("xona yuq")
//         }
//     }
// }

// 3.masala
// let number = +prompt("ixtiyoriy son kiriting")
// console.log(number);

// if (number % 3==0 && number % 5==0) {
//     alert("fizz - bass")
// }else{
//     if (number % 3==0) {
//         alert("fizz")
//     }else{
//         if (number % 5 ==0) {
//             alert("bass")
//         }
//     }
// }

// 4.masala

let number = +prompt("ixtiyoriy son kiriting")
console.log(number);

let number2 = +prompt("ixtiyoriy son kiriting")
console.log(number2);

let number3 = +prompt("ixtiyoriy son kiriting")
console.log(number3);

if (number > number2 && number2 > number3) {
    alert("number3 hammasidan kichik")
}else{
    if (number > number3 && number3 > number2) {
        alert("number2 hammasidan kichik")
    }
}
if (number2 > number && number > number3) {
    alert("number3 hammasidan kichik")
}else{
    if (number2 > number3 && number3 > number) {
        alert("number1 hammasidan kichik")
    }
}

if (number3 > number && number > number2) {
    alert("number2 hammasidan kichik")
}else{
    if (number3 > number2 && number2 > number) {
        alert("number1 hammasidan kichik")
    }
}

